"""
Sarvam AI Proxy — Server initialization and route setup.
"""

import argparse
import json
import time
import uuid

from aiohttp import web

from .api import (
    proxy_tts, proxy_stt_ws, proxy_voice_agent,
    fetch_samvaad_config, get_samvaad_signed_url,
    openai_chat_completions, openai_models,
    openai_audio_speech, openai_audio_transcriptions,
    cors_middleware, close_http,
    refresh_cookies, start_cookie_refresh, stop_cookie_refresh, handle_refresh,
    SPEAKERS, LANGUAGES, TTS_MODELS, STT_MODELS,
)

_samvaad_apps = []

async def load_samvaad_config(app):
    global _samvaad_apps
    try:
        _samvaad_apps = await fetch_samvaad_config()
        print(f"[sarvam-proxy] Loaded {len(_samvaad_apps)} Samvaad apps")
    except Exception as e:
        print(f"[sarvam-proxy] Failed to load Samvaad config: {e}")
        _samvaad_apps = []

async def startup(app):
    await load_samvaad_config(app)
    print("[sarvam-proxy] Refreshing cookies...")
    results = await refresh_cookies()
    total = sum(r.get("cookies", 0) for r in results)
    print(f"[sarvam-proxy] Cookie refresh: {total} cookies from {len(results)} sites")
    start_cookie_refresh(app)

async def shutdown(app):
    stop_cookie_refresh()
    await close_http()

async def handle_tts(request):
    try:
        body = await request.json()
    except:
        return web.json_response({"error": "Invalid JSON"}, status=400)
    text = body.get("text", "")
    if not text:
        return web.json_response({"error": "Missing 'text'"}, status=400)
    if len(text) > 5000:
        return web.json_response({"error": "Text too long (max 5000 chars)"}, status=400)
    speaker = body.get("speaker", "shubh")
    lang = body.get("lang", "hi-IN")
    model = body.get("model", "bulbul:v3-beta")
    pace = float(body.get("pace", 1.1))
    sample_rate = int(body.get("sample_rate", 22050))
    temperature = float(body.get("temperature", 0.6))
    codec = body.get("codec", "mp3")
    try:
        audio = await proxy_tts(text, speaker, lang, model, pace, sample_rate, temperature, codec)
        return web.Response(
            body=audio,
            content_type=f"audio/{codec}",
            headers={"Content-Disposition": f'inline; filename="sarvam-tts.{codec}"'},
        )
    except Exception as e:
        return web.json_response({"error": str(e)}, status=502)

async def handle_stt_ws(request):
    ws = web.WebSocketResponse()
    await ws.prepare(request)
    lang = request.query.get("language", "unknown")
    model = request.query.get("model", "saaras:v3")
    mode = request.query.get("mode", "transcribe")
    await proxy_stt_ws(ws, lang=lang, model=model, mode=mode)
    return ws

async def handle_agent_ws(request):
    ws = web.WebSocketResponse()
    await ws.prepare(request)
    global _samvaad_apps
    if not _samvaad_apps:
        await ws.send_json({"type": "error", "message": "No Samvaad apps available"})
        await ws.close()
        return ws
    app_index = int(request.query.get("app", "0"))
    if app_index >= len(_samvaad_apps):
        app_index = 0
    app = _samvaad_apps[app_index]
    sample_rate = int(request.query.get("sample_rate", 16000))
    await proxy_voice_agent(ws, org_id=app["orgId"], workspace_id=app["workspaceId"], app_id=app["appId"], sample_rate=sample_rate)
    return ws

async def handle_samvaad_config(request):
    global _samvaad_apps
    return web.json_response(_samvaad_apps)

async def handle_info(request):
    return web.json_response({
        "name": "Sarvam AI Proxy",
        "version": "2.0.0",
        "features": {
            "tts": {
                "endpoints": ["POST /api/tts", "POST /v1/audio/speech"],
                "models": list(TTS_MODELS.keys()),
                "speakers": list(SPEAKERS.keys()),
                "languages": list(LANGUAGES.keys()),
            },
            "stt": {
                "endpoints": ["GET /api/stt-ws (WebSocket)", "POST /v1/audio/transcriptions"],
                "models": list(STT_MODELS.keys()),
            },
            "voice_agent": {
                "endpoints": ["GET /api/agent-ws (WebSocket)"],
                "apps": _samvaad_apps,
            },
            "openai_compatible": {
                "chat": ["POST /v1/chat/completions"],
                "audio": ["POST /v1/audio/speech", "POST /v1/audio/transcriptions"],
                "models": ["GET /v1/models"],
            },
        },
    })

async def handle_health(request):
    return web.json_response({"status": "ok", "version": "2.0.0"})

async def handle_ui(request):
    html = generate_ui()
    return web.Response(text=html, content_type="text/html", charset="utf-8")

def generate_ui():
    lang_options = "".join(
        f'<option value="{c}">{n}</option>' for c, n in LANGUAGES.items()
    )
    speaker_cards = "".join(
        f'''
        <button class="speaker-btn" data-speaker="{name}"
                onclick="selectSpeaker('{name}')">
          <div class="speaker-name">{name.title()}</div>
          <div class="speaker-style">{info["style"]}</div>
          <div class="speaker-gender">{info["gender"]}</div>
        </button>'''
        for name, info in SPEAKERS.items()
    )

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Sarvam AI Proxy</title>
<link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>🔊</text></svg>">
<style>
  :root {{
    --bg: #08080f;
    --surface: #111118;
    --surface2: #1a1a26;
    --surface3: #24243a;
    --border: #2a2a40;
    --text: #e8e8f0;
    --text2: #8888a8;
    --accent: #7c5cfc;
    --accent2: #5a3fd4;
    --green: #34d399;
    --red: #f87171;
    --amber: #fbbf24;
    --blue: #60a5fa;
    --radius: 12px;
  }}
  * {{ box-sizing: border-box; margin: 0; padding: 0; }}
  body {{
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif;
    background: var(--bg); color: var(--text); min-height: 100vh;
  }}
  .layout {{ display: flex; min-height: 100vh; }}
  .sidebar {{
    width: 200px; flex-shrink: 0; background: var(--surface);
    border-right: 1px solid var(--border); padding: 20px 0;
    display: flex; flex-direction: column;
  }}
  .sidebar-brand {{ padding: 0 20px 20px; border-bottom: 1px solid var(--border); margin-bottom: 12px; }}
  .sidebar-brand h1 {{ font-size: 16px; font-weight: 700; }}
  .sidebar-nav {{ flex: 1; overflow-y: auto; }}
  .nav-item {{
    display: flex; align-items: center; gap: 8px; padding: 10px 20px;
    color: var(--text2); cursor: pointer; transition: all 0.2s;
    font-size: 13px; border: none; background: none; width: 100%; text-align: left;
  }}
  .nav-item:hover {{ color: var(--text); background: rgba(124,92,252,0.08); }}
  .nav-item.active {{ color: var(--accent); background: rgba(124,92,252,0.12); border-right: 2px solid var(--accent); }}
  .main {{ flex: 1; padding: 24px; overflow-y: auto; max-width: 1000px; }}
  .tab-content {{ display: none; }}
  .tab-content.active {{ display: block; }}
  .card {{
    background: var(--surface); border: 1px solid var(--border);
    border-radius: var(--radius); padding: 24px; margin-bottom: 20px;
  }}
  .card h2 {{ font-size: 18px; font-weight: 600; margin-bottom: 16px; display: flex; align-items: center; gap: 8px; }}
  .card h3 {{ font-size: 14px; font-weight: 600; margin-bottom: 10px; color: var(--text2); text-transform: uppercase; letter-spacing: 0.5px; }}
  textarea, input[type="text"] {{
    width: 100%; padding: 12px; border-radius: 8px;
    background: var(--surface2); border: 1px solid var(--border);
    color: var(--text); font-size: 14px; font-family: inherit; resize: vertical;
  }}
  textarea:focus, input:focus {{ outline: none; border-color: var(--accent); }}
  select {{
    width: 100%; padding: 8px 10px; border-radius: 8px; background: var(--surface2);
    border: 1px solid var(--border); color: var(--text); font-size: 13px;
  }}
  .form-row {{ display: flex; gap: 12px; flex-wrap: wrap; margin: 12px 0; }}
  .form-group {{ flex: 1; min-width: 130px; }}
  .form-group label {{ display: block; font-size: 11px; color: var(--text2); margin-bottom: 4px; text-transform: uppercase; letter-spacing: 0.5px; }}
  .range-row {{ display: flex; align-items: center; gap: 10px; }}
  .range-row input[type="range"] {{ flex: 1; }}
  .range-value {{ font-size: 13px; color: var(--accent); min-width: 30px; text-align: right; }}
  .speaker-grid {{ display: grid; grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 10px; margin: 12px 0; }}
  .speaker-btn {{
    padding: 12px; border-radius: 8px; background: var(--surface2);
    border: 2px solid var(--border); color: var(--text); cursor: pointer;
    text-align: left; transition: all 0.2s;
  }}
  .speaker-btn:hover {{ border-color: var(--accent); }}
  .speaker-btn.active {{ border-color: var(--accent); background: rgba(124,92,252,0.15); }}
  .speaker-name {{ font-weight: 600; font-size: 14px; }}
  .speaker-style {{ font-size: 11px; color: var(--text2); margin-top: 2px; }}
  .speaker-gender {{ font-size: 10px; color: var(--text2); opacity: 0.7; }}
  .btn {{
    padding: 10px 22px; border: none; border-radius: 8px; font-size: 14px;
    font-weight: 600; cursor: pointer; transition: all 0.2s;
  }}
  .btn-primary {{ background: var(--accent); color: white; }}
  .btn-primary:hover {{ background: var(--accent2); transform: translateY(-1px); }}
  .btn-primary:disabled {{ opacity: 0.4; cursor: not-allowed; transform: none; }}
  .btn-secondary {{ background: var(--surface2); color: var(--text); border: 1px solid var(--border); }}
  .btn-secondary:hover {{ border-color: var(--accent); }}
  .btn-danger {{ background: rgba(248,113,113,0.15); color: var(--red); border: 1px solid rgba(248,113,113,0.3); }}
  .actions {{ display: flex; gap: 10px; margin: 16px 0; align-items: center; flex-wrap: wrap; }}
  .player {{ margin-top: 16px; display: none; }}
  .player.show {{ display: block; }}
  .player audio {{ width: 100%; }}
  .status {{ font-size: 13px; color: var(--text2); padding: 6px 0; }}
  .status.error {{ color: var(--red); }}
  .status.success {{ color: var(--green); }}
  .status.info {{ color: var(--blue); }}
  .badge {{ display: inline-block; font-size: 10px; padding: 2px 8px; border-radius: 10px; background: rgba(124,92,252,0.15); color: var(--accent); margin-left: 8px; }}
  .pill {{ display: inline-block; font-size: 11px; padding: 3px 10px; border-radius: 20px; margin: 2px; }}
  .pill-green {{ background: rgba(52,211,153,0.15); color: var(--green); }}
  .pill-amber {{ background: rgba(251,191,36,0.15); color: var(--amber); }}
  .pill-blue {{ background: rgba(96,165,250,0.15); color: var(--blue); }}
  .record-btn {{ width: 60px; height: 60px; border-radius: 50%; border: none; cursor: pointer; transition: all 0.2s; font-size: 24px; }}
  .record-btn.idle {{ background: var(--surface2); color: var(--text2); border: 2px solid var(--border); }}
  .record-btn.recording {{ background: rgba(248,113,113,0.2); color: var(--red); border: 2px solid var(--red); animation: pulse 1.5s infinite; }}
  @keyframes pulse {{ 0%, 100% {{ transform: scale(1); }} 50% {{ transform: scale(1.05); }} }}
  .waveform {{ height: 60px; background: var(--surface2); border-radius: 8px; margin: 12px 0; display: flex; align-items: center; justify-content: center; color: var(--text2); font-size: 13px; }}
  .agent-status {{
    display: flex; align-items: center; gap: 8px; padding: 12px; border-radius: 8px;
    margin: 12px 0; font-size: 14px;
  }}
  .agent-status.connecting {{ background: rgba(96,165,250,0.1); color: var(--blue); }}
  .agent-status.connected {{ background: rgba(52,211,153,0.1); color: var(--green); }}
  .agent-status.listening {{ background: rgba(251,191,36,0.1); color: var(--amber); }}
  .agent-status.speaking {{ background: rgba(124,92,252,0.1); color: var(--accent); }}
  .agent-status.error {{ background: rgba(248,113,113,0.1); color: var(--red); }}
  .status-dot {{ width: 8px; height: 8px; border-radius: 50%; display: inline-block; }}
  .status-dot.connecting {{ background: var(--blue); animation: pulse 1s infinite; }}
  .status-dot.connected {{ background: var(--green); }}
  .status-dot.listening {{ background: var(--amber); animation: pulse 1.5s infinite; }}
  .status-dot.speaking {{ background: var(--accent); animation: pulse 0.8s infinite; }}
  .status-dot.error {{ background: var(--red); }}
  pre {{ background: var(--surface2); padding: 16px; border-radius: 8px; font-size: 13px; overflow-x: auto; border: 1px solid var(--border); }}
  code {{ font-family: 'JetBrains Mono', 'Fira Code', monospace; }}
  footer {{ text-align: center; padding: 30px 0; color: var(--text2); font-size: 12px; }}
  @media (max-width: 768px) {{ .sidebar {{ width: 60px; }} .sidebar-brand h1, .sidebar-brand p, .nav-item span {{ display: none; }} .main {{ padding: 16px; }} }}
</style>
</head>
<body>
<div class="layout">
  <div class="sidebar">
    <div class="sidebar-brand">
      <h1>Sarvam AI</h1>
      <p>Proxy</p>
    </div>
    <div class="sidebar-nav">
      <button class="nav-item active" onclick="switchTab('tts', this)"><span>🔊</span><span>TTS</span></button>
      <button class="nav-item" onclick="switchTab('stt', this)"><span>🎙</span><span>STT</span></button>
      <button class="nav-item" onclick="switchTab('agent', this)"><span>🤖</span><span>Voice Agent</span></button>
      <button class="nav-item" onclick="switchTab('openai', this)"><span>🔄</span><span>OpenAI API</span></button>
    </div>
  </div>

  <div class="main">
    <div id="tab-tts" class="tab-content active">
      <div class="card">
        <h2>🔊 Text to Speech</h2>
        <p style="color:var(--text2);font-size:14px;margin-bottom:16px">Generate natural-sounding speech in 11 Indian languages. Free playground APIs.</p>
        <textarea id="tts-text" rows="3" placeholder="Enter text in Hindi, English, or other Indian languages...">\u092d\u093e\u0930\u0924 \u0915\u0940 \u0938\u0941\u092c\u0939 \u0915\u093e \u0928\u091c\u093c\u093e\u0930\u093e \u0939\u0940 \u0915\u0941\u091b \u0914\u0930 \u0939\u094b\u0924\u093e \u0939\u0948\u0964</textarea>
        <div class="form-row">
          <div class="form-group">
            <label>Language</label>
            <select id="tts-lang">{lang_options}</select>
          </div>
          <div class="form-group">
            <label>Model</label>
            <select id="tts-model">
              <option value="bulbul:v3-beta">bulbul:v3-beta (beta)</option>
              <option value="bulbul:v3">bulbul:v3 (stable)</option>
            </select>
          </div>
          <div class="form-group">
            <label>Codec</label>
            <select id="tts-codec">
              <option value="mp3">MP3</option>
              <option value="wav">WAV</option>
              <option value="pcm">PCM</option>
            </select>
          </div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label>Pace: <span id="tts-pace-val">1.1</span></label>
            <div class="range-row">
              <span style="font-size:11px;color:var(--text2)">Slow</span>
              <input type="range" id="tts-pace" min="0.5" max="2.0" step="0.1" value="1.1" oninput="document.getElementById('tts-pace-val').textContent=this.value">
              <span style="font-size:11px;color:var(--text2)">Fast</span>
            </div>
          </div>
          <div class="form-group">
            <label>Temperature: <span id="tts-temp-val">0.6</span></label>
            <div class="range-row">
              <span style="font-size:11px;color:var(--text2)">Flat</span>
              <input type="range" id="tts-temp" min="0.0" max="1.0" step="0.1" value="0.6" oninput="document.getElementById('tts-temp-val').textContent=this.value">
              <span style="font-size:11px;color:var(--text2)">Varied</span>
            </div>
          </div>
          <div class="form-group">
            <label>Sample Rate</label>
            <select id="tts-sr">
              <option value="8000">8 kHz</option>
              <option value="16000">16 kHz</option>
              <option value="22050" selected>22.05 kHz</option>
              <option value="44100">44.1 kHz</option>
              <option value="48000">48 kHz</option>
            </select>
          </div>
        </div>
        <div class="form-group" style="margin-top:8px">
          <label>Voice <span class="badge">Select below</span></label>
        </div>
        <div class="speaker-grid" id="tts-speaker-grid">
          {speaker_cards}
        </div>
        <div class="actions">
          <button class="btn btn-primary" id="tts-gen-btn" onclick="generateTTS()">🔊 Generate</button>
          <button class="btn btn-secondary" onclick="document.getElementById('tts-text').value='';document.getElementById('tts-player').classList.remove('show')">Clear</button>
          <span id="tts-chars" class="status" style="flex:1;text-align:right">0 chars</span>
        </div>
        <div id="tts-player" class="player">
          <audio id="tts-audio" controls></audio>
          <div style="margin-top:8px;display:flex;gap:8px;flex-wrap:wrap;align-items:center">
            <a id="tts-dl" class="btn btn-secondary" style="font-size:13px;padding:6px 14px;text-decoration:none" download="sarvam-tts.mp3">⬇ Download</a>
            <span id="tts-size" class="status"></span>
          </div>
        </div>
        <div id="tts-status" class="status"></div>
      </div>
    </div>

    <div id="tab-stt" class="tab-content">
      <div class="card">
        <h2>🎙 Speech to Text</h2>
        <p style="color:var(--text2);font-size:14px;margin-bottom:16px">Record audio and get transcriptions in Indian languages.</p>
        <div class="form-row">
          <div class="form-group">
            <label>Language</label>
            <select id="stt-lang">
              <option value="unknown">Auto-detect</option>
              {lang_options}
            </select>
          </div>
          <div class="form-group">
            <label>Model</label>
            <select id="stt-model">
              <option value="saaras:v3">saaras:v3</option>
            </select>
          </div>
        </div>
        <div style="display:flex;flex-direction:column;align-items:center;padding:30px 0">
          <button id="stt-record-btn" class="record-btn idle" onclick="toggleSTT()">🎙</button>
          <div class="status" style="margin-top:8px" id="stt-rec-status">Click to start recording</div>
        </div>
        <div class="waveform" id="stt-waveform">
          <span id="stt-wave-text">Audio will appear here while recording...</span>
        </div>
        <div class="form-group" style="margin-top:12px">
          <label>Transcript</label>
          <textarea id="stt-transcript" rows="4" placeholder="Transcription will appear here..." readonly></textarea>
        </div>
        <div class="actions">
          <button class="btn btn-secondary" onclick="navigator.clipboard.writeText(document.getElementById('stt-transcript').value)">📋 Copy</button>
          <button class="btn btn-secondary" onclick="document.getElementById('stt-transcript').value=''">Clear</button>
        </div>
        <div id="stt-status" class="status"></div>
      </div>
    </div>

    <div id="tab-agent" class="tab-content">
      <div class="card">
        <h2>🤖 Voice Agent <span class="badge">Samvaad</span></h2>
        <p style="color:var(--text2);font-size:14px;margin-bottom:16px">Conversational AI agent. Speak and get spoken responses in real-time.</p>
        <div class="form-row">
          <div class="form-group">
            <label>App</label>
            <select id="agent-app">
              <option value="0">Default Voice Agent</option>
            </select>
          </div>
          <div class="form-group">
            <label>Sample Rate</label>
            <select id="agent-sr">
              <option value="8000">8 kHz</option>
              <option value="16000" selected>16 kHz</option>
              <option value="22050">22.05 kHz</option>
              <option value="44100">44.1 kHz</option>
            </select>
          </div>
        </div>
        <div id="agent-status" class="agent-status idle" style="display:none">
          <span class="status-dot idle"></span>
          <span id="agent-status-text">Initializing...</span>
        </div>
        <div style="display:flex;flex-direction:column;align-items:center;padding:20px 0">
          <button id="agent-call-btn" class="btn btn-primary" onclick="toggleAgent()" style="font-size:18px;padding:16px 40px;border-radius:50px">
            📞 Start Call
          </button>
          <div class="status" style="margin-top:8px" id="agent-status-line">Click to start a voice conversation</div>
        </div>
        <div id="agent-conversation" style="display:none">
          <h3>Conversation</h3>
          <div class="chat-messages" id="agent-messages"></div>
        </div>
        <div id="agent-status-msg" class="status"></div>
      </div>
    </div>

    <div id="tab-openai" class="tab-content">
      <div class="card">
        <h2>🔄 OpenAI-Compatible API</h2>
        <p style="color:var(--text2);font-size:14px;margin-bottom:16px">Drop-in replacement for OpenAI audio endpoints. Free, no API key needed.</p>
        <h3>Available Endpoints</h3>
        <pre><code>POST {{window.location.origin}}/v1/audio/speech        # TTS
GET  {{window.location.origin}}/v1/models               # List models</code></pre>
        <h3 style="margin-top:16px">Configuration</h3>
        <pre><code># Python with OpenAI SDK
from openai import OpenAI
client = OpenAI(
    base_url="{{window.location.origin}}/v1",
    api_key="not-needed",
)
# TTS
response = client.audio.speech.create(
    model="bulbul:v3-beta",
    voice="shubh",
    input="\u0928\u092e\u0938\u094d\u0924\u0947",
)
response.stream_to_file("output.mp3")

# STT is only available via WebSocket:
# ws://{{window.location.host}}/api/stt-ws</code></pre>
        <h3 style="margin-top:16px">Test It</h3>
        <div class="actions">
          <button class="btn btn-primary" onclick="testOpenAI()">🔄 Test Connection</button>
          <span id="openai-test-result" class="status"></span>
        </div>
      </div>
    </div>

    <footer>
      Powered by <a href="https://www.sarvam.ai" target="_blank">Sarvam AI</a> playground APIs &bull;
      Unofficial proxy &bull; Free to use
    </footer>
  </div>
</div>

<script>
function switchTab(tab, btn) {{
  document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  document.getElementById('tab-' + tab).classList.add('active');
  btn.classList.add('active');
}}

let ttsSpeaker = 'shubh';
document.querySelector('#tts-speaker-grid .speaker-btn')?.classList.add('active');
document.getElementById('tts-text').addEventListener('input', () => {{
  document.getElementById('tts-chars').textContent = document.getElementById('tts-text').value.length + ' chars';
}});
document.getElementById('tts-text').dispatchEvent(new Event('input'));

function selectSpeaker(name) {{
  ttsSpeaker = name;
  document.querySelectorAll('#tts-speaker-grid .speaker-btn').forEach(b => b.classList.remove('active'));
  document.querySelector(`#tts-speaker-grid .speaker-btn[data-speaker="${{name}}"]`)?.classList.add('active');
}}

async function generateTTS() {{
  const text = document.getElementById('tts-text').value.trim();
  if (!text) {{ setTTSStatus('Please enter text', 'error'); return; }}
  if (text.length > 5000) {{ setTTSStatus('Text too long (max 5000 chars)', 'error'); return; }}
  const btn = document.getElementById('tts-gen-btn');
  btn.disabled = true; btn.textContent = '\u23f3 Generating...';
  setTTSStatus('Generating...', '');
  try {{
    const resp = await fetch('/api/tts', {{
      method: 'POST',
      headers: {{ 'Content-Type': 'application/json' }},
      body: JSON.stringify({{
        text, speaker: ttsSpeaker, lang: document.getElementById('tts-lang').value,
        model: document.getElementById('tts-model').value,
        pace: parseFloat(document.getElementById('tts-pace').value),
        sample_rate: parseInt(document.getElementById('tts-sr').value),
        temperature: parseFloat(document.getElementById('tts-temp').value),
        codec: document.getElementById('tts-codec').value,
      }}),
    }});
    if (!resp.ok) {{ const e = await resp.text(); throw new Error(e.substring(0, 200)); }}
    const blob = await resp.blob();
    const url = URL.createObjectURL(blob);
    const ext = document.getElementById('tts-codec').value === 'mp3' ? 'mp3' : 'wav';
    const player = document.getElementById('tts-player');
    document.getElementById('tts-audio').src = url;
    player.classList.add('show');
    document.getElementById('tts-dl').href = url;
    document.getElementById('tts-dl').download = `sarvam-tts-${{ttsSpeaker}}.${{ext}}`;
    document.getElementById('tts-size').textContent = `${{(blob.size / 1024).toFixed(1)}} KB`;
    setTTSStatus('\u2714 Generated!', 'success');
    document.getElementById('tts-audio').play().catch(() => {{}});
  }} catch (e) {{ setTTSStatus('\u2718 ' + e.message, 'error'); }}
  finally {{ btn.disabled = false; btn.textContent = '\U0001f50a Generate'; }}
}}
function setTTSStatus(msg, type) {{ const el = document.getElementById('tts-status'); el.textContent = msg; el.className = 'status ' + type; }}

let sttActive = false;
let sttWS = null;
let sttStream = null;
let sttAudioCtx = null;
let sttProcessor = null;
let sttSource = null;

async function toggleSTT() {{
  if (sttActive) {{ stopSTT(); return; }}
  const btn = document.getElementById('stt-record-btn');
  const lang = document.getElementById('stt-lang').value;
  try {{
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${{protocol}}//${{window.location.host}}/api/stt-ws?language=${{lang}}&model=saaras:v3&mode=transcribe`;
    sttWS = new WebSocket(wsUrl);
    sttWS.onopen = async () => {{
      sttActive = true;
      btn.className = 'record-btn recording';
      btn.textContent = '\u23f9';
      document.getElementById('stt-rec-status').textContent = '\U0001f534 Recording... Click to stop';
      document.getElementById('stt-wave-text').textContent = 'Listening...';
      document.getElementById('stt-status').className = 'status';
      document.getElementById('stt-status').textContent = '';
      try {{
        sttStream = await navigator.mediaDevices.getUserMedia({{ audio: {{ sampleRate: 16000, channelCount: 1, echoCancellation: true, noiseSuppression: true }}}});
        sttAudioCtx = new AudioContext({{ sampleRate: 16000 }});
        sttSource = sttAudioCtx.createMediaStreamSource(sttStream);
        sttProcessor = sttAudioCtx.createScriptProcessor(4096, 1, 1);
        sttProcessor.onaudioprocess = (e) => {{
          if (!sttActive || !sttWS || sttWS.readyState !== WebSocket.OPEN) return;
          const input = e.inputBuffer.getChannelData(0);
          const pcm16 = new Int16Array(input.length);
          for (let i = 0; i < input.length; i++) {{ const s = Math.max(-1, Math.min(1, input[i])); pcm16[i] = s < 0 ? s * 0x8000 : s * 0x7FFF; }}
          sttWS.send(pcm16.buffer);
        }};
        sttSource.connect(sttProcessor);
        sttProcessor.connect(sttAudioCtx.destination);
      }} catch (micErr) {{ setSTTStatus('\u2718 Mic error: ' + micErr.message, 'error'); stopSTT(); }}
    }};
    sttWS.onmessage = (e) => {{
      try {{
        const data = JSON.parse(e.data);
        if (data.type === 'data' && data.data?.transcript) {{
          document.getElementById('stt-transcript').value += data.data.transcript + ' ';
          document.getElementById('stt-transcript').scrollTop = document.getElementById('stt-transcript').scrollHeight;
        }} else if (data.type === 'events' && data.data?.signal_type === 'START_SPEECH') {{
          document.getElementById('stt-wave-text').textContent = 'Speaking...';
        }} else if (data.type === 'events' && data.data?.signal_type === 'END_SPEECH') {{
          document.getElementById('stt-wave-text').textContent = 'Processing...';
        }}
      }} catch {{}}
    }};
    sttWS.onerror = () => {{ setSTTStatus('WebSocket error', 'error'); stopSTT(); }};
    sttWS.onclose = () => {{ if (sttActive) {{ stopSTT(); }} }};
  }} catch (e) {{ setSTTStatus('\u2718 ' + e.message, 'error'); }}
}}

function stopSTT() {{
  sttActive = false;
  if (sttWS) {{ sttWS.send(JSON.stringify({{ type: 'stop' }})); sttWS.close(); }}
  if (sttProcessor) sttProcessor.disconnect();
  if (sttSource) sttSource.disconnect();
  if (sttAudioCtx) sttAudioCtx.close();
  if (sttStream) sttStream.getTracks().forEach(t => t.stop());
  const btn = document.getElementById('stt-record-btn');
  btn.className = 'record-btn idle';
  btn.textContent = '\U0001f399';
  document.getElementById('stt-rec-status').textContent = 'Click to start recording';
  document.getElementById('stt-wave-text').textContent = 'Recording stopped';
}}
function setSTTStatus(msg, type) {{ const el = document.getElementById('stt-status'); el.textContent = msg; el.className = 'status ' + type; }}

let agentActive = false;
let agentWS = null;
let agentCtx = null;
let agentNextTime = 0;

async function playAgentChunk(b64, sr) {{
  if (!agentCtx) agentCtx = window.agentAudioCtx || new AudioContext();
  if (agentCtx.state === 'suspended') await agentCtx.resume();
  if (agentNextTime < agentCtx.currentTime) agentNextTime = agentCtx.currentTime;
  const raw = atob(b64);
  const pcm = new Int16Array(raw.length / 2);
  for (let i = 0; i < pcm.length; i++) pcm[i] = (raw.charCodeAt(i * 2) | (raw.charCodeAt(i * 2 + 1) << 8));
  const float = new Float32Array(pcm.length);
  for (let i = 0; i < pcm.length; i++) float[i] = pcm[i] / 32768;
  const buf = agentCtx.createBuffer(1, float.length, sr);
  buf.getChannelData(0).set(float);
  const src = agentCtx.createBufferSource();
  src.buffer = buf;
  src.connect(agentCtx.destination);
  src.start(agentNextTime);
  agentNextTime += float.length / sr;
}}

async function toggleAgent() {{
  if (agentActive) {{ stopAgent(); return; }}
  const btn = document.getElementById('agent-call-btn');
  const appIdx = document.getElementById('agent-app').value;
  const sr = document.getElementById('agent-sr').value;
  try {{
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${{protocol}}//${{window.location.host}}/api/agent-ws?app=${{appIdx}}&sample_rate=${{sr}}`;
    agentWS = new WebSocket(wsUrl);
    agentWS.onopen = () => {{
      agentActive = true;
      btn.textContent = '\U0001f534 End Call';
      btn.className = 'btn btn-danger';
      document.getElementById('agent-status').style.display = 'flex';
      document.getElementById('agent-status').className = 'agent-status connecting';
      document.getElementById('agent-status-text').textContent = 'Connecting to agent...';
      document.getElementById('agent-conversation').style.display = 'block';
      document.getElementById('agent-status-line').textContent = 'Connected! You can speak now.';
      addAgentMsg('system', 'Connected. Start speaking...');
    }};
    agentWS.onmessage = (e) => {{
      try {{
        const data = JSON.parse(e.data);
        if (data.type === 'interaction_connected') {{
          document.getElementById('agent-status').className = 'agent-status listening';
          document.getElementById('agent-status-text').textContent = 'Listening... You can speak';
        }} else if (data.type === 'agent.text' || data.type === 'agent.text_chunk') {{
          addAgentMsg('assistant', data.text || '');
          document.getElementById('agent-status').className = 'agent-status speaking';
          document.getElementById('agent-status-text').textContent = 'Agent is speaking...';
         }} else if (data.type === 'agent.audio_chunk') {{
           if (data.audio_base64) {{
             playAgentChunk(data.audio_base64, data.sample_rate || parseInt(sr));
           }}
           if (data.status === 'completed') {{ document.getElementById('agent-status').className = 'agent-status listening'; document.getElementById('agent-status-text').textContent = 'Listening...'; }}
           else {{ document.getElementById('agent-status').className = 'agent-status speaking'; document.getElementById('agent-status-text').textContent = 'Agent is speaking...'; }}
        }} else if (data.type === 'interaction_end') {{ addAgentMsg('system', 'Conversation ended.'); stopAgent(); }}
        else if (data.type === 'error') {{ setAgentStatus('\u2718 ' + data.message, 'error'); stopAgent(); }}
      }} catch {{}}
    }};
    agentWS.onerror = () => {{ setAgentStatus('WebSocket error', 'error'); stopAgent(); }};
    agentWS.onclose = () => {{ if (agentActive) {{ stopAgent(); }} }};
    const stream = await navigator.mediaDevices.getUserMedia({{ audio: {{ sampleRate: 16000, channelCount: 1, echoCancellation: true, noiseSuppression: true }}}});
    window.agentStream = stream;
    const audioCtx = new AudioContext({{ sampleRate: parseInt(sr) }});
    window.agentAudioCtx = audioCtx;
    window.agentCtx = audioCtx;
    const source = audioCtx.createMediaStreamSource(stream);
    const processor = audioCtx.createScriptProcessor(4096, 1, 1);
    processor.onaudioprocess = (e) => {{
      if (!agentActive || !agentWS || agentWS.readyState !== WebSocket.OPEN) return;
      const input = e.inputBuffer.getChannelData(0);
      const pcm16 = new Int16Array(input.length);
      for (let i = 0; i < input.length; i++) {{ const s = Math.max(-1, Math.min(1, input[i])); pcm16[i] = s < 0 ? s * 0x8000 : s * 0x7FFF; }}
      agentWS.send(pcm16.buffer);
    }};
    source.connect(processor);
    const mute = audioCtx.createGain();
    mute.gain.value = 0;
    processor.connect(mute);
    mute.connect(audioCtx.destination);
    window.agentProcessor = processor;
    window.agentSource = source;
  }} catch (e) {{ setAgentStatus('\u2718 ' + e.message, 'error'); btn.textContent = '\U0001f4de Start Call'; btn.className = 'btn btn-primary'; }}
}}

function stopAgent() {{
  agentActive = false;
  if (agentCtx) {{ agentCtx.close(); agentCtx = null; }}
  agentNextTime = 0;
  if (agentWS && agentWS.readyState === WebSocket.OPEN) {{ agentWS.send(JSON.stringify({{ type: 'client.interaction_end' }})); agentWS.close(); }}
  if (window.agentStream) {{ window.agentStream.getTracks().forEach(t => t.stop()); }}
  if (window.agentAudioCtx) {{ window.agentAudioCtx.close(); }}
  if (window.agentProcessor) {{ window.agentProcessor.disconnect(); }}
  if (window.agentSource) {{ window.agentSource.disconnect(); }}
  const btn = document.getElementById('agent-call-btn');
  btn.textContent = '\U0001f4de Start Call';
  btn.className = 'btn btn-primary';
  document.getElementById('agent-status-line').textContent = 'Call ended. Click to start again';
}}

function addAgentMsg(role, text) {{ if (!text) return; const container = document.getElementById('agent-messages'); const div = document.createElement('div'); div.className = 'chat-msg ' + role; div.textContent = text; container.appendChild(div); container.scrollTop = container.scrollHeight; }}
function setAgentStatus(msg, type) {{ const el = document.getElementById('agent-status-msg'); el.textContent = msg; el.className = 'status ' + type; }}

async function testOpenAI() {{
  const el = document.getElementById('openai-test-result');
  el.textContent = 'Testing...';
  el.className = 'status';
  try {{
    const resp = await fetch('/v1/models');
    const data = await resp.json();
    el.textContent = `\u2714 Connected! ${{data.data?.length || 0}} models available`;
    el.className = 'status success';
  }} catch (e) {{ el.textContent = '\u2718 ' + e.message; el.className = 'status error'; }}
}}
</script>
</body>
</html>"""

def create_app():
    app = web.Application(middlewares=[cors_middleware])
    app.router.add_get("/", handle_ui)
    app.router.add_get("/health", handle_health)
    app.router.add_get("/api/info", handle_info)
    app.router.add_get("/api/samvaad/config", handle_samvaad_config)
    app.router.add_post("/api/tts", handle_tts)
    app.router.add_get("/api/stt-ws", handle_stt_ws)
    app.router.add_get("/api/agent-ws", handle_agent_ws)
    app.router.add_get("/api/refresh", handle_refresh)
    app.router.add_post("/api/refresh", handle_refresh)
    app.router.add_get("/v1/models", openai_models)
    app.router.add_post("/v1/chat/completions", openai_chat_completions)
    app.router.add_post("/v1/audio/speech", openai_audio_speech)
    app.router.add_post("/v1/audio/transcriptions", openai_audio_transcriptions)
    app.on_startup.append(startup)
    app.on_shutdown.append(shutdown)
    return app

def main():
    parser = argparse.ArgumentParser(description="Sarvam AI Proxy")
    parser.add_argument("--port", "-p", type=int, default=8080, help="Port (default: 8080)")
    parser.add_argument("--host", "-H", default="0.0.0.0", help="Host (default: 0.0.0.0)")
    args = parser.parse_args()
    host = args.host
    port = args.port
    print(f"Sarvam AI Proxy")
    print(f"   Web UI:  http://{host}:{port}/")
    print(f"   API:     http://{host}:{port}/api/tts")
    print(f"   WS STT:  ws://{host}:{port}/api/stt-ws")
    print(f"   WS Agent: ws://{host}:{port}/api/agent-ws")
    print(f"   OpenAI:  http://{host}:{port}/v1/")
    print(f"   Press Ctrl+C to stop")
    app = create_app()
    web.run_app(app, host=host, port=port)

if __name__ == "__main__":
    main()

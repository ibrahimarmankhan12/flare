#!/usr/bin/env python3
"""
Sarvam AI API CLI — Unofficial client for Sarvam AI playground & production APIs.

Uses the unauthenticated playground endpoint by default (no API key needed).
For higher limits and production use, sign up at https://dashboard.sarvam.ai
and pass your API key with --api-key or SARVAM_API_KEY env var.

Reverse-engineered from the public website at https://www.sarvam.ai/
"""

import argparse
import json
import os
import sys
import time
import warnings
from pathlib import Path
from urllib.parse import urlencode

warnings.filterwarnings("ignore")

try:
    import requests
except ImportError:
    print("requests not installed. Run: pip install requests")
    sys.exit(1)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

PLAYGROUND_TTS_URL = "https://www.sarvam.ai/api/playground/tts"
PRODUCTION_TTS_URL = "https://api.sarvam.ai/text-to-speech"

# Known voices from the website demo
# Playground only supports these 4 speakers
PLAYGROUND_SPEAKERS = {
    "shubh":   {"gender": "Male",   "style": "Conversational · Friendly"},
    "shreya":  {"gender": "Female", "style": "News · Authoritative"},
    "manan":   {"gender": "Male",   "style": "Conversational · Consistent"},
    "ishita":  {"gender": "Female", "style": "Entertainment · Dynamic"},
}

# Production API adds more speakers
PRODUCTION_SPEAKERS = {
    **PLAYGROUND_SPEAKERS,
    "anushka": {"gender": "Female", "style": "Conversational (SDK default)"},
}

# Language codes supported by the TTS API
LANGUAGES = {
    "hi-IN": "Hindi",
    "bn-IN": "Bengali",
    "ta-IN": "Tamil",
    "te-IN": "Telugu",
    "mr-IN": "Marathi",
    "gu-IN": "Gujarati",
    "kn-IN": "Kannada",
    "ml-IN": "Malayalam",
    "pa-IN": "Punjabi",
    "or-IN": "Odia",
    "en-IN": "English (Indian)",
}

MODELS = {
    "bulbul:v3":      "Production model (recommended)",
    "bulbul:v3-beta": "Latest beta/gamma model (playground default)",
}

# ---------------------------------------------------------------------------
# Core TTS function
# ---------------------------------------------------------------------------


def tts_playground(
    text: str,
    speaker: str = "shubh",
    lang: str = "hi-IN",
    model: str = "bulbul:v3-beta",
    pace: float = 1.1,
    sample_rate: int = 22050,
    temperature: float = 0.6,
    preprocess: bool = True,
    codec: str = "mp3",
    output: str | None = None,
) -> bytes:
    """Call the unauthenticated Sarvam AI playground TTS endpoint.

    Returns raw audio bytes.
    """
    payload = {
        "text": text,
        "target_language_code": lang,
        "speaker": speaker,
        "model": model,
        "pace": pace,
        "speech_sample_rate": sample_rate,
        "temperature": temperature,
        "enable_preprocessing": preprocess,
        "output_audio_codec": codec,
    }

    headers = {
        "Content-Type": "application/json",
        "Origin": "https://www.sarvam.ai",
        "Referer": "https://www.sarvam.ai/",
        "Accept": "*/*",
    }

    resp = requests.post(PLAYGROUND_TTS_URL, json=payload, headers=headers, timeout=120)
    resp.raise_for_status()

    audio = resp.content
    if output:
        Path(output).write_bytes(audio)
        print(f"Saved {len(audio) / 1024:.1f} KB → {output}")
    return audio


def tts_production(
    text: str,
    api_key: str,
    speaker: str = "anushka",
    lang: str = "hi-IN",
    model: str = "bulbul:v3",
    pace: float = 1.0,
    sample_rate: int = 22050,
    output: str | None = None,
) -> bytes:
    """Call the authenticated Sarvam AI production TTS API.

    Requires an API key from https://dashboard.sarvam.ai
    """
    payload = {
        "inputs": [text],
        "target_language_code": lang,
        "speaker": speaker,
        "model": model,
        "pace": pace,
        "speech_sample_rate": sample_rate,
    }

    headers = {
        "Content-Type": "application/json",
        "api-subscription-key": api_key,
    }

    resp = requests.post(PRODUCTION_TTS_URL, json=payload, headers=headers, timeout=120)
    resp.raise_for_status()

    data = resp.json()
    # The production API returns base64-encoded audio
    import base64

    audio_data = data.get("audios", [None])[0]
    if not audio_data:
        print("No audio returned. Response:")
        print(json.dumps(data, indent=2))
        return b""

    audio = base64.b64decode(audio_data)
    if output:
        Path(output).write_bytes(audio)
        ext = Path(output).suffix or ".wav"
        print(f"Saved {len(audio) / 1024:.1f} KB → {output}")
    return audio


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def list_speakers():
    """Print available speakers."""
    print("Playground speakers (no API key needed):")
    print(f"{'Name':<12} {'Gender':<9} {'Style':<35}")
    print("-" * 56)
    for name, info in PLAYGROUND_SPEAKERS.items():
        print(f"{name:<12} {info['gender']:<9} {info['style']:<35}")
    print()
    print("Additional production speakers (with API key):")
    extra = {k: v for k, v in PRODUCTION_SPEAKERS.items() if k not in PLAYGROUND_SPEAKERS}
    for name, info in extra.items():
        print(f"{name:<12} {info['gender']:<9} {info['style']:<35}")
    print()
    print("Usage:  --speaker shubh")


def list_languages():
    """Print available languages."""
    print(f"{'Code':<10} {'Language'}")
    print("-" * 30)
    for code, name in LANGUAGES.items():
        print(f"{code:<10} {name}")
    print()
    print("Usage:  --lang hi-IN")


def list_models():
    """Print available models."""
    print(f"{'Model':<25} {'Description'}")
    print("-" * 55)
    for m, desc in MODELS.items():
        print(f"{m:<25} {desc}")


def demo_demo():
    """Run a demonstration showing all playground-compatible speakers."""
    text = (
        "भारत की सुबह का नज़ारा ही कुछ और होता है। "
        "चाय की चुस्की के साथ अखबार, बच्चों की किलकारियां, "
        "और मंदिर की घंटियों की आवाज़, सब मिलकर एक ऐसा माहौल "
        "बनाते हैं जो दिल को सुकून देता है।"
    )

    print("=" * 60)
    print("  Sarvam AI TTS Demo — All Voices")
    print("=" * 60)
    print(f'  Text: {text[:60]}…')
    print()

    output_dir = Path("sarvam_demo_output")
    output_dir.mkdir(exist_ok=True)

    for speaker in PLAYGROUND_SPEAKERS:
        print(f"  Generating: {speaker} … ", end="", flush=True)
        out = output_dir / f"demo_{speaker}.mp3"
        try:
            tts_playground(text=text, speaker=speaker, output=str(out))
            print("✔")
        except Exception as e:
            print(f"✘ {e}")
        time.sleep(0.5)

    print(f"\n  All files in: {output_dir}/")
    print("  Done!")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main():
    parser = argparse.ArgumentParser(
        description="Sarvam AI API CLI — Text-to-Speech & more",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Basic TTS (playground, no API key needed):
  python sarvam-cli.py speak --text "नमस्ते" --output hello.mp3

  # Use a different voice and language:
  python sarvam-cli.py speak --text "Hello" --speaker shreya --lang en-IN --output hello.mp3

  # Read text from a file (one line, or full paragraph):
  python sarvam-cli.py speak --file speech.txt --speaker manan --output speech.mp3

  # Tune voice characteristics:
  python sarvam-cli.py speak --text "नमस्ते" --pace 1.5 --temperature 0.8 --output fast.mp3

  # Use production API (requires key from dashboard.sarvam.ai):
  python sarvam-cli.py speak --text "नमस्ते" --api-key $SARVAM_API_KEY --output hello.wav

  # List available voices:
  python sarvam-cli.py speakers

  # Generate a demo with all voices:
  python sarvam-cli.py demo

Report issues at: https://github.com/sarvamai
Website: https://www.sarvam.ai
        """,
    )

    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # --- speak ---
    speak = subparsers.add_parser("speak", help="Convert text to speech")
    text_group = speak.add_mutually_exclusive_group(required=True)
    text_group.add_argument("--text", "-t", help="Text to synthesize")
    text_group.add_argument("--file", "-f", help="Read text from a file")
    speak.add_argument("--speaker", "-s", default="shubh", choices=list(PLAYGROUND_SPEAKERS), help="Voice speaker")
    speak.add_argument("--lang", "-l", default="hi-IN", choices=list(LANGUAGES), help="Language code")
    speak.add_argument(
        "--model",
        "-m",
        default="bulbul:v3-beta",
        choices=list(MODELS),
        help="TTS model",
    )
    speak.add_argument("--pace", type=float, default=1.1, help="Speaking pace (0.5–2.0)")
    speak.add_argument("--sample-rate", type=int, default=22050, help="Sample rate (8000–48000)")
    speak.add_argument("--temperature", type=float, default=0.6, help="Voice variability (0.0–1.0)")
    speak.add_argument("--codec", default="mp3", choices=["mp3", "wav", "pcm"], help="Output audio codec")
    speak.add_argument("--output", "-o", required=True, help="Output file path (.mp3/.wav)")
    speak.add_argument("--api-key", help="Production API key (uses playground if omitted)")
    speak.add_argument("--rate-limit", type=float, default=0.5, help="Seconds between requests")

    # --- speakers ---
    subparsers.add_parser("speakers", help="List available speakers/voices")

    # --- languages ---
    subparsers.add_parser("languages", help="List available languages")

    # --- models ---
    subparsers.add_parser("models", help="List available models")

    # --- demo ---
    subparsers.add_parser("demo", help="Run full voice demo with all speakers")

    args = parser.parse_args()

    # Resolve API key from env
    api_key = getattr(args, "api_key", None) or os.environ.get("SARVAM_API_KEY")

    match args.command:
        case "speak":
            # Resolve text: from --text flag or from --file
            if args.file:
                text = Path(args.file).read_text(encoding="utf-8")
            else:
                text = args.text

            if args.api_key:
                tts_production(
                    text=text,
                    api_key=api_key,
                    speaker=args.speaker,
                    lang=args.lang,
                    model=args.model,
                    pace=args.pace,
                    sample_rate=args.sample_rate,
                    output=args.output,
                )
            else:
                tts_playground(
                    text=text,
                    speaker=args.speaker,
                    lang=args.lang,
                    model=args.model,
                    pace=args.pace,
                    sample_rate=args.sample_rate,
                    temperature=args.temperature,
                    codec=args.codec,
                    output=args.output,
                )

        case "speakers":
            list_speakers()
        case "languages":
            list_languages()
        case "models":
            list_models()
        case "demo":
            demo_demo()
        case _:
            parser.print_help()


if __name__ == "__main__":
    main()

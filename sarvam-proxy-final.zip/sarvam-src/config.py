import json
import os

DEFAULT_CONFIG = {
    "server": {
        "host": "0.0.0.0",
        "port": 8080,
    },
    "gateway": {
        "rate_limit": {
            "enabled": False,
            "requests_per_minute": 60,
            "burst_size": 10,
        },
        "auth": {
            "enabled": False,
            "api_keys": [],
        },
        "cors": {
            "allowed_origins": ["*"],
            "allowed_methods": "GET, POST, PUT, DELETE, OPTIONS",
            "allowed_headers": "Content-Type, Authorization, X-API-Key",
        },
    },
    "logging": {
        "level": "INFO",
        "format": "text",
    },
    "proxy": {
        "timeout": 120,
        "max_tts_chars": 5000,
    },
}


def load_config(config_path=None):
    config = json.loads(json.dumps(DEFAULT_CONFIG))

    if config_path and os.path.exists(config_path):
        with open(config_path) as f:
            _deep_merge(config, json.load(f))

    if os.environ.get("GATEWAY_PORT"):
        config["server"]["port"] = int(os.environ["GATEWAY_PORT"])
    if os.environ.get("GATEWAY_HOST"):
        config["server"]["host"] = os.environ["GATEWAY_HOST"]
    if os.environ.get("RATE_LIMIT_ENABLED"):
        config["gateway"]["rate_limit"]["enabled"] = os.environ["RATE_LIMIT_ENABLED"].lower() == "true"
    if os.environ.get("RATE_LIMIT_RPM"):
        config["gateway"]["rate_limit"]["requests_per_minute"] = int(os.environ["RATE_LIMIT_RPM"])
    if os.environ.get("AUTH_ENABLED"):
        config["gateway"]["auth"]["enabled"] = os.environ["AUTH_ENABLED"].lower() == "true"
    if os.environ.get("API_KEYS"):
        config["gateway"]["auth"]["api_keys"] = [k.strip() for k in os.environ["API_KEYS"].split(",")]
    if os.environ.get("LOG_LEVEL"):
        config["logging"]["level"] = os.environ["LOG_LEVEL"].upper()
    if os.environ.get("LOG_FORMAT"):
        config["logging"]["format"] = os.environ["LOG_FORMAT"].lower()

    return config


def _deep_merge(base, override):
    for key, value in override.items():
        if key in base and isinstance(base[key], dict) and isinstance(value, dict):
            _deep_merge(base[key], value)
        else:
            base[key] = value

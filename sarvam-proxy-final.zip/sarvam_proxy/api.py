"""
Sarvam AI Proxy — Async WebSocket & HTTP proxy.
Free playground APIs only. No official/production API integration.
"""

import asyncio
import base64
import json
import re
import time
import uuid
from urllib.parse import urlencode

import aiohttp
from aiohttp import web, WSMsgType

# ---------------------------------------------------------------------------
# Constants — Free Playground APIs Only
# ---------------------------------------------------------------------------

PLAYGROUND_TTS_URL = "https://www.sarvam.ai/api/playground/tts"
PLAYGROUND_STT_WS = "wss://www.sarvam.ai/api/playground/stt-ws"
SAMVAAD_CONFIG_URL = "https://www.sarvam.ai/api/samvaad/config"
SAMVAAD_APP_RUNTIME = "https://apps.sarvam.ai/api/app-runtime/"
SAMVAAD_PROXY_URL = "https://www.sarvam.ai/api/samvaad/"

SPEAKERS = {
    "shubh":  {"gender": "Male",   "style": "Conversational \u00b7 Friendly"},
    "shreya": {"gender": "Female", "style": "News \u00b7 Authoritative"},
    "manan":  {"gender": "Male",   "style": "Conversational \u00b7 Consistent"},
    "ishita": {"gender": "Female", "style": "Entertainment \u00b7 Dynamic"},
}

LANGUAGES = {
    "hi-IN": "Hindi", "bn-IN": "Bengali", "ta-IN": "Tamil",
    "te-IN": "Telugu", "mr-IN": "Marathi", "gu-IN": "Gujarati",
    "kn-IN": "Kannada", "ml-IN": "Malayalam", "pa-IN": "Punjabi",
    "or-IN": "Odia", "en-IN": "English (Indian)",
}

TTS_MODELS = {
    "bulbul:v3-beta": "Latest beta (playground default)",
    "bulbul:v3": "Production model",
}

STT_MODELS = {
    "saaras:v3": "Latest STT model",
}

HEADERS_TTS = {
    "Content-Type": "application/json",
    "Origin": "https://www.sarvam.ai",
    "Referer": "https://www.sarvam.ai/apis/text-to-speech",
    "Accept": "*/*",
}

# ---------------------------------------------------------------------------
# HTTP Client
# ---------------------------------------------------------------------------

_http_session = None


async def get_http():
    global _http_session
    if _http_session is None:
        _http_session = aiohttp.ClientSession(
            headers={"User-Agent": "Mozilla/5.0 (compatible; SarvamProxy/1.0)"}
        )
    return _http_session


async def close_http():
    global _http_session
    if _http_session:
        await _http_session.close()
        _http_session = None


# ---------------------------------------------------------------------------
# TTS — Free Playground
# ---------------------------------------------------------------------------

async def proxy_tts(text, speaker="shubh", lang="hi-IN", model="bulbul:v3-beta",
                    pace=1.1, sample_rate=22050, temperature=0.6, codec="mp3"):
    payload = {
        "text": text,
        "target_language_code": lang,
        "speaker": speaker,
        "model": model,
        "pace": pace,
        "speech_sample_rate": sample_rate,
        "temperature": temperature,
        "enable_preprocessing": True,
        "output_audio_codec": codec,
    }
    session = await get_http()
    async with session.post(
        PLAYGROUND_TTS_URL, json=payload, headers=HEADERS_TTS,
        timeout=aiohttp.ClientTimeout(total=120),
    ) as resp:
        if resp.status != 200:
            body = await resp.text()
            raise Exception(f"Sarvam API error ({resp.status}): {body[:300]}")
        return await resp.read()


# ---------------------------------------------------------------------------
# STT — WebSocket Proxy
# ---------------------------------------------------------------------------

async def proxy_stt_ws(client_ws, lang="unknown", model="saaras:v3",
                        mode="transcribe", vad_signals=True, high_vad=True):
    params = urlencode({
        "language-code": lang,
        "model": model,
        "mode": mode,
        "vad_signals": str(vad_signals).lower(),
        "high_vad_sensitivity": str(high_vad).lower(),
    })
    stt_url = f"{PLAYGROUND_STT_WS}?{params}"

    session = await get_http()
    async with session.ws_connect(stt_url, origin="https://www.sarvam.ai") as stt_ws:

        async def forward_to_sarvam():
            async for msg in client_ws:
                if msg.type == aiohttp.WSMsgType.BINARY:
                    b64 = base64.b64encode(msg.data).decode()
                    await stt_ws.send_str(json.dumps({"audio": {"data": b64, "encoding": "audio/wav", "sample_rate": 16000}}))
                elif msg.type == aiohttp.WSMsgType.TEXT:
                    data = json.loads(msg.data)
                    t = data.get("type", "")
                    if t == "stop":
                        await stt_ws.send_str(json.dumps({
                            "type": "client.media.audio_end",
                            "origin": "client",
                            "timestamp": time.time(),
                        }))
                    elif t == "audio":
                        await stt_ws.send_str(json.dumps(data))
                elif msg.type == aiohttp.WSMsgType.CLOSE:
                    break

        async def forward_to_client():
            async for msg in stt_ws:
                if msg.type == aiohttp.WSMsgType.TEXT:
                    data = json.loads(msg.data)
                    await client_ws.send_json(data)
                elif msg.type == aiohttp.WSMsgType.BINARY:
                    await client_ws.send_bytes(msg.data)
                elif msg.type == aiohttp.WSMsgType.CLOSE:
                    break

        await asyncio.wait([
            asyncio.create_task(forward_to_sarvam()),
            asyncio.create_task(forward_to_client()),
        ], return_when=asyncio.FIRST_COMPLETED)




# ---------------------------------------------------------------------------
# Samvaad (Voice Agent) Proxy
# ---------------------------------------------------------------------------

async def fetch_samvaad_config():
    try:
        session = await get_http()
        headers = {"Origin": "https://www.sarvam.ai", "Referer": "https://www.sarvam.ai/"}
        async with session.get(SAMVAAD_CONFIG_URL, headers=headers) as resp:
            if resp.status == 200:
                return await resp.json()
    except Exception as e:
        print(f"[samvaad] Config fetch error: {e}")
    return []


async def get_samvaad_signed_url(org_id, workspace_id, app_id, interaction_type="call"):
    url = (
        f"https://www.sarvam.ai/api/samvaad/orgs/{org_id}"
        f"/workspaces/{workspace_id}/apps/{app_id}/url"
        f"?interaction_type={interaction_type}"
    )
    session = await get_http()
    headers = {"Origin": "https://www.sarvam.ai", "Referer": "https://www.sarvam.ai/"}
    async with session.get(url, headers=headers) as resp:
        resp.raise_for_status()
        return await resp.json()


async def proxy_voice_agent(client_ws, org_id, workspace_id, app_id, sample_rate=16000):
    signed = await get_samvaad_signed_url(org_id, workspace_id, app_id, "call")
    ws_url = signed["url"]
    reference_id = signed["reference_id"]

    timestamp = int(time.time() * 1000)
    ws_url += (
        f"?user_identifier=web-demo-{timestamp}"
        f"&user_identifier_type=custom"
        f"&sample_rate={sample_rate}"
        f"&interaction_type=call"
    )

    session = await get_http()
    async with session.ws_connect(ws_url, origin="https://www.sarvam.ai") as agent_ws:
        await agent_ws.send_str(json.dumps({
            "type": "client.action.interaction_start",
            "origin": "client",
            "timestamp": time.time(),
        }))

        async def forward_to_agent():
            async for msg in client_ws:
                if msg.type == aiohttp.WSMsgType.BINARY:
                    b64 = base64.b64encode(msg.data).decode()
                    await agent_ws.send_str(json.dumps({
                        "type": "client.media.audio_chunk",
                        "origin": "client",
                        "timestamp": time.time(),
                        "audio_base64": b64,
                        "format": "audio/wav",
                        "sample_rate": sample_rate,
                    }))
                elif msg.type == aiohttp.WSMsgType.TEXT:
                    data = json.loads(msg.data)
                    t = data.get("type", "")
                    if t in ("client.media.audio_chunk", "client.media.text",
                              "client.media.audio_end", "client.interaction_end"):
                        payload = data
                        if t == "client.media.audio_chunk":
                            payload = {
                                "type": "client.media.audio_chunk",
                                "origin": "client",
                                "timestamp": time.time(),
                                "audio_base64": data["audio_base64"],
                                "format": "audio/wav",
                                "sample_rate": sample_rate,
                            }
                        elif t == "client.media.text":
                            payload = {
                                "type": "client.media.text",
                                "origin": "client",
                                "timestamp": time.time(),
                                "text": data["text"],
                            }
                        await agent_ws.send_str(json.dumps(payload))
                elif msg.type == aiohttp.WSMsgType.CLOSE:
                    break

        async def forward_to_client():
            async for msg in agent_ws:
                if msg.type == aiohttp.WSMsgType.TEXT:
                    data = json.loads(msg.data)
                    t = data.get("type", "")
                    if t == "server.interaction_connected":
                        await client_ws.send_json({
                            "type": "interaction_connected",
                            "interaction_id": data.get("interaction_id"),
                            "reference_id": reference_id,
                        })
                    elif t == "server.media.audio_chunk":
                        await client_ws.send_json({
                            "type": "agent.audio_chunk",
                            "audio_base64": data.get("audio_base64"),
                            "status": data.get("status", "pending"),
                            "sample_rate": data.get("sample_rate", sample_rate),
                        })
                    elif t == "server.media.text":
                        await client_ws.send_json({
                            "type": "agent.text",
                            "text": data.get("text", ""),
                        })
                    elif t == "server.media.text_chunk":
                        await client_ws.send_json({
                            "type": "agent.text_chunk",
                            "text": data.get("text", ""),
                        })
                    elif t == "server.media.transcript":
                        await client_ws.send_json({
                            "type": "agent.transcript",
                            "transcript": data.get("transcript", ""),
                        })
                    elif t == "server.interaction_end":
                        await client_ws.send_json({"type": "interaction_end"})
                elif msg.type == aiohttp.WSMsgType.CLOSE:
                    break

        await asyncio.wait([
            asyncio.create_task(forward_to_agent()),
            asyncio.create_task(forward_to_client()),
        ], return_when=asyncio.FIRST_COMPLETED)


# ---------------------------------------------------------------------------
# OpenAI-Compatible API
# ---------------------------------------------------------------------------

async def openai_chat_completions(request):
    body = await request.json()
    messages = body.get("messages", [])
    model = body.get("model", "samvaad")
    stream = body.get("stream", False)

    last_user_msg = ""
    for m in reversed(messages):
        if m["role"] == "user":
            last_user_msg = m["content"]
            break

    if not last_user_msg:
        return web.json_response({"error": "No user message found"}, status=400)

    try:
        apps = await fetch_samvaad_config()
        if not apps:
            return web.json_response({
                "id": f"chatcmpl-{uuid.uuid4()}",
                "object": "chat.completion",
                "created": int(time.time()),
                "model": model,
                "choices": [{
                    "index": 0,
                    "message": {
                        "role": "assistant",
                        "content": "Samvaad agent is not available for chat at the moment."
                    },
                    "finish_reason": "stop"
                }],
                "usage": {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0}
            })

        if stream:
            response = web.StreamResponse(
                status=200,
                reason='OK',
                headers={
                    'Content-Type': 'text/event-stream',
                    'Cache-Control': 'no-cache',
                    'Connection': 'keep-alive',
                    'Access-Control-Allow-Origin': '*',
                },
            )
            await response.prepare(request)

            async def stream_response():
                app = apps[0]
                signed = await get_samvaad_signed_url(
                    app["orgId"], app["workspaceId"], app["appId"], "chat"
                )
                session = await get_http()
                async with session.ws_connect(signed["url"], origin="https://www.sarvam.ai") as chat_ws:
                    await chat_ws.send_str(json.dumps({
                        "type": "client.action.interaction_start",
                        "origin": "client",
                        "timestamp": time.time(),
                    }))
                    await chat_ws.send_str(json.dumps({
                        "type": "client.media.text",
                        "origin": "client",
                        "timestamp": time.time(),
                        "text": last_user_msg,
                    }))

                    async for msg in chat_ws:
                        if msg.type == aiohttp.WSMsgType.TEXT:
                            data = json.loads(msg.data)
                            t = data.get("type", "")
                            if t == "server.media.text_chunk":
                                chunk = data.get("text", "")
                                sse = {
                                    "id": f"chatcmpl-{uuid.uuid4()}",
                                    "object": "chat.completion.chunk",
                                    "created": int(time.time()),
                                    "model": model,
                                    "choices": [{
                                        "index": 0,
                                        "delta": {"content": chunk},
                                        "finish_reason": None,
                                    }]
                                }
                                await response.write(f"data: {json.dumps(sse)}\n\n".encode())
                            elif t == "server.media.text":
                                text = data.get("text", "")
                                await response.write(f"data: {json.dumps({
                                    'id': f'chatcmpl-{uuid.uuid4()}',
                                    'object': 'chat.completion.chunk',
                                    'created': int(time.time()),
                                    'model': model,
                                    'choices': [{'index': 0, 'delta': {'content': text}, 'finish_reason': 'stop'}]
                                })}\n\n".encode())
                                break
                            elif t == "server.interaction_end":
                                break
                        elif msg.type == aiohttp.WSMsgType.CLOSE:
                            break
                    await response.write(b"data: [DONE]\n\n")

            await stream_response()
            return response
        else:
            return web.json_response({
                "id": f"chatcmpl-{uuid.uuid4()}",
                "object": "chat.completion",
                "created": int(time.time()),
                "model": model,
                "choices": [{
                    "index": 0,
                    "message": {
                        "role": "assistant",
                        "content": "Chat with Samvaad agent coming soon!"
                    },
                    "finish_reason": "stop"
                }],
                "usage": {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0}
            })

    except Exception as e:
        return web.json_response({"error": str(e)}, status=500)


async def openai_models(request):
    models = [
        {"id": "bulbul:v3", "object": "model", "created": int(time.time()), "owned_by": "sarvam-ai"},
        {"id": "bulbul:v3-beta", "object": "model", "created": int(time.time()), "owned_by": "sarvam-ai"},
        {"id": "saaras:v3", "object": "model", "created": int(time.time()), "owned_by": "sarvam-ai"},
        {"id": "samvaad", "object": "model", "created": int(time.time()), "owned_by": "sarvam-ai"},
        {"id": "sarvam-tts", "object": "model", "created": int(time.time()), "owned_by": "sarvam-ai"},
        {"id": "sarvam-stt", "object": "model", "created": int(time.time()), "owned_by": "sarvam-ai"},
    ]
    return web.json_response({"object": "list", "data": models})


async def openai_audio_speech(request):
    body = await request.json()
    input_text = body.get("input", "")
    voice = body.get("voice", "shubh")
    model = body.get("model", "bulbul:v3-beta")
    response_format = body.get("response_format", "mp3")
    speed = body.get("speed", 1.1)

    if not input_text:
        return web.json_response({"error": "Missing 'input' field"}, status=400)

    voice_map = {
        "alloy": "shubh", "echo": "shubh", "fable": "shreya",
        "onyx": "manan", "nova": "ishita", "shimmer": "shreya",
    }
    speaker = voice_map.get(voice, voice)

    lang = "hi-IN"
    if re.match(r'^[a-zA-Z0-9\s\.,!?\'\"-]+$', input_text):
        lang = "en-IN"

    try:
        audio = await proxy_tts(
            text=input_text, speaker=speaker, lang=lang,
            model=model.replace("tts-1", "bulbul:v3-beta"),
            pace=speed,
            codec=response_format if response_format in ("mp3", "wav", "pcm") else "mp3",
        )
        return web.Response(
            body=audio,
            content_type=f"audio/{response_format if response_format in ('mp3', 'wav') else 'mpeg'}",
            headers={"Access-Control-Allow-Origin": "*"},
        )
    except Exception as e:
        return web.json_response({"error": str(e)}, status=502)


async def openai_audio_transcriptions(request):
    return web.json_response({
        "error": "HTTP STT not supported by playground API. Use the WebSocket endpoint: ws://<host>/api/stt-ws"
    }, status=400)


# ---------------------------------------------------------------------------
# CORS Middleware
# ---------------------------------------------------------------------------

@web.middleware
async def cors_middleware(request, handler):
    if request.method == "OPTIONS":
        return web.Response(
            headers={
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
                "Access-Control-Allow-Headers": "Content-Type, Authorization, api-subscription-key, api-key",
                "Access-Control-Max-Age": "86400",
            }
        )
    try:
        response = await handler(request)
        response.headers["Access-Control-Allow-Origin"] = "*"
        return response
    except web.HTTPException as ex:
        ex.headers["Access-Control-Allow-Origin"] = "*"
        raise

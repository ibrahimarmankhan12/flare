#!/usr/bin/env python3
"""
Sarvam AI Gateway — Start the API gateway server.
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from sarvam_proxy.server import main

if __name__ == "__main__":
    main()

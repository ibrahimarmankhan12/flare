import { MetadataRoute } from "next";

const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || "https://flare-sh.tech";
const sitemapLastUpdated = new Date("2026-03-05T00:00:00.000Z");

type SitemapEntry = {
  path: string;
  changeFrequency: MetadataRoute.Sitemap[number]["changeFrequency"];
  priority: number;
  lastModified?: Date;
};

const entries: SitemapEntry[] = [
  {
    path: "/",
    changeFrequency: "weekly",
    priority: 1.0,
    lastModified: new Date("2026-03-05T00:00:00.000Z"),
  },
  {
    path: "/about",
    changeFrequency: "monthly",
    priority: 0.8,
    lastModified: new Date("2026-02-20T00:00:00.000Z"),
  },
  {
    path: "/privacy-policy",
    changeFrequency: "yearly",
    priority: 0.5,
    lastModified: new Date("2026-01-15T00:00:00.000Z"),
  },
  {
    path: "/terms-of-service",
    changeFrequency: "yearly",
    priority: 0.5,
    lastModified: new Date("2026-01-15T00:00:00.000Z"),
  },
  {
    path: "/cookies-policy",
    changeFrequency: "yearly",
    priority: 0.3,
    lastModified: new Date("2026-01-15T00:00:00.000Z"),
  },
  {
    path: "/refund-policy",
    changeFrequency: "yearly",
    priority: 0.3,
    lastModified: new Date("2026-01-15T00:00:00.000Z"),
  },
];

export const revalidate = 43200;

export default function sitemap(): MetadataRoute.Sitemap {
  return entries.map((entry) => ({
    url: `${siteUrl}${entry.path}`,
    lastModified: entry.lastModified ?? sitemapLastUpdated,
    changeFrequency: entry.changeFrequency,
    priority: entry.priority,
  }));
}
